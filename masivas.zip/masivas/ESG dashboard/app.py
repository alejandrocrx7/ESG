import requests
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

# SQLAlchemy base
Base = declarative_base()

# Modelo de tabla
class Metric(Base):
    __tablename__ = 'metricas'
    
    id = Column(Integer, primary_key=True)
    nombre = Column(String)
    valor = Column(Float)
    fecha = Column(DateTime)

# Conexión a PostgreSQL
engine = create_engine("postgresql://postgres:rootpass@postgres_master:5432/energia_db")
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()

# Lista de endpoints y los JSON que cada uno requiere
endpoints = [
    {
        "url": "http://servapibi.xm.com.co/hourly",
        "json_body": {
            "MetricId": "DemaReal",
            "MetricName": "Demanda Real por Sistema",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Sistema",
            "Filter": []
        }
    },
    {
        "url": "http://servapibi.xm.com.co/hourly",
        "json_body": {
            "MetricId": "Gene",
            "MetricName": "Generación por Sistema",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Sistema",
            "Filter": []
        }
    },
    {
        "url": "http://servapibi.xm.com.co/hourly",
        "json_body": {
            "MetricId": " factorEmisionCO2e",
            "MetricName": " Emisiones de CO2 Eq/kWh por Sistema",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Sistema",
            "Filter": []
        }
    },
    {
        "url": "http://servapibi.xm.com.co/hourly",
        "json_body": {
            "MetricId": "PrecBolsNaci",
            "MetricName": "Precio Bolsa Nacional por Sistema",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Sistema",
            "Filter": []
        }
    },
    {
        "url": "http://servapibi.xm.com.co/hourly",
        "json_body": {
            "MetricId": "PerdidasEner",
            "MetricName": "Perdidas de Energía por Sistema",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Sistema",
            "Filter": []
        }
    },
    {
        "url": "http://servapibi.xm.com.co/daily",
        "json_body": {
            "MetricId": "AporEner",
            "MetricName": "Aportes Energía por Sistema",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Sistema",
            "Filter": []
        }
    },
    {
        "url": "http://servapibi.xm.com.co/daily",
        "json_body": {
            "MetricId": "DemaSIN",
            "MetricName": "Demanda Energia SIN por Sistema",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Sistema",
            "Filter": []
        }
    },
    {
        "url": "http://servapibi.xm.com.co/daily",
        "json_body": {
            "MetricId": "PPPrecBolsNaci",
            "MetricName": "Precio Bolsa Nacional Ponderado por Sistema",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Sistema",
            "Filter": []
        }
    },
    {
        "url": "http://servapibi.xm.com.co/hourly",
        "json_body": {
            "MetricId": "Gene",
            "MetricName": "Generación por Recurso",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Recurso",
            "Filter": ["Codigo Submercado Generación"]
        }
    },
    {
        "url": "http://servapibi.xm.com.co/hourly",
        "json_body": {
            "MetricId": "DispoReal",
            "MetricName": "Disponibilidad Real por Recurso",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Recurso",
            "Filter": ["Codigo Submercado Generación"]
        }
    },
    {
        "url": "http://servapibi.xm.com.co/hourly",
        "json_body": {
            "MetricId": "ConsCombustibleMBTU",
            "MetricName": "Consumo Combustible MBTU por Recurso",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Recurso",
            "Filter": ["Codigo Submercado Generación"]
        }
    },
    {
        "url": "http://servapibi.xm.com.co/hourly",
        "json_body": {
            "MetricId": "EmisionesCO2",
            "MetricName": "Emisiones de CO2 por RecursoComb",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "RecursoComb",
            "Filter": ["Codigo Submercado Generación"]
        }
    },
    {
        "url": "http://servapibi.xm.com.co/hourly",
        "json_body": {
            "MetricId": "EmisionesCO2Eq",
            "MetricName": "Emisiones de CO2 Eq por Recurso",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Recurso",
            "Filter": ["Codigo Submercado Generación"]
        }
    },
    {
        "url": "http://servapibi.xm.com.co/hourly",
        "json_body": {
            "MetricId": "DemaReal",
            "MetricName": "Demanda Real por Agente",
            "StartDate": "2025-02-01",
            "EndDate": "2025-03-01",
            "Entity": "Agente",
            "Filter": ["Codigo Comercializador"]
        }
    }
]

# Función para hacer la petición POST a cada API
def obtener_metricas_post(url, body):
    headers = {
        "Content-Type": "application/json"
    }
    try:
        response = requests.post(url, json=body, headers=headers)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error al obtener métricas de {url}. Código: {response.status_code}")
            return []
    except Exception as e:
        print(f"Error de conexión con {url}: {e}")
        return []

# Función para guardar métricas
def guardar_metricas(metricas):
    for metrica in metricas:
        try:
            nombre = metrica["nombre"]
            valor = float(metrica["valor"])
            fecha = datetime.strptime(metrica["fecha"], "%Y-%m-%d %H:%M:%S")
            
            nueva_metrica = Metric(nombre=nombre, valor=valor, fecha=fecha)
            session.add(nueva_metrica)
        except Exception as e:
            print(f"Error al guardar una métrica: {e}")
    
    session.commit()

# Función principal para orquestar el proceso
def procesar_todas_las_metricas():
    for endpoint in endpoints:
        datos = obtener_metricas_post(endpoint["url"], endpoint["json_body"])
        if datos:
            guardar_metricas(datos)

# Ejecutar
procesar_todas_las_metricas()

# Cerrar sesión
session.close()
