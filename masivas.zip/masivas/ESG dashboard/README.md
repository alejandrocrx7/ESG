Sistema de Métricas Energéticas con Sharding y Replicación

Este proyecto implementa un sistema distribuido de recolección de métricas energéticas utilizando:

- PostgreSQL con replicación (master y 2 réplicas)
- Sharding por hora usando `table inheritance`
- Docker para contenerización
- FastAPI para exponer una API RESTful
- SQLAlchemy para ORM en Python

Paso 1: Levantar los contenedores

1. Asegúrate de tener instalado Docker y Docker Compose.
2. Ejecuta:

```bash
docker-compose up -d

postgres_master (Puerto 5432)

postgres_replica1 (Puerto 5433)

postgres_replica2 (Puerto 5434)

api (Puerto 8000)

instalar dependencias 

pip install psycopg2-binary sqlalchemy requests

crear entorno virtual

python -m venv venv
source venv/bin/activate   # En Linux/macOS
venv\Scripts\activate.bat  # En Windows
