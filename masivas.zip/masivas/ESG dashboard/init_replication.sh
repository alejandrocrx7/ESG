#!/bin/bash
set -e

echo "Configurando PostgreSQL para replicación..."

# Esperamos a que el contenedor inicie PostgreSQL
sleep 5

# Crear usuario de replicación
psql -U postgres <<EOF
CREATE ROLE replicator WITH REPLICATION LOGIN ENCRYPTED PASSWORD 'replica_pass';
EOF

# Modificar archivos de configuración
echo "wal_level = replica" >> "$PGDATA/postgresql.conf"
echo "max_wal_senders = 10" >> "$PGDATA/postgresql.conf"
echo "hot_standby = on" >> "$PGDATA/postgresql.conf"
echo "archive_mode = on" >> "$PGDATA/postgresql.conf"
echo "archive_command = 'cd .'" >> "$PGDATA/postgresql.conf"  # Dummy command

# Permitir conexiones de replicación desde cualquier IP
echo "host replication replicator 0.0.0.0/0 md5" >> "$PGDATA/pg_hba.conf"

echo "✅ Replicación configurada en el nodo master."
