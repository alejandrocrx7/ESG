# cargar_datos_xm.py

import requests
import pandas as pd
import psycopg2
import time
from datetime import datetime, timedelta

# Parámetros de conexión a PostgreSQL
DB_PARAMS = {
    'dbname': 'esg_bd',
    'user': 'postgres',
    'password': 'admin',
    'host': 'postgres_master',  # Cambiado de 'localhost' a 'postgres_master'
    'port': 5432
}

# Fechas para los últimos 3 años
END_DATE = datetime.today().strftime("%Y-%m-%d")
START_DATE = (datetime.today() - timedelta(days=3 * 365)).strftime("%Y-%m-%d")

# Ruta al archivo Excel
EXCEL_PATH = "datos_API.xlsx"

# Mapeo simple de MetricId hacia tabla
TABLA_POR_METRICA = {
    'DemaReal': 'demanda_energia',
    'Gene': 'generacion_energia',
    'Infra': 'infraestructura',
    'Soste': 'sostenibilidad_regulacion',
    'Mercado': 'mercado_mayorista'
}

# Cargar la hoja SINERGOX
df = pd.read_excel(EXCEL_PATH, sheet_name="SINERGOX")

# Conectar a la base de datos con reintento
def conectar_db(max_retries=5, delay=5):
    retries = 0
    conn = None
    while retries < max_retries:
        try:
            conn = psycopg2.connect(**DB_PARAMS)
            print("Conexión a la base de datos exitosa.")
            return conn
        except psycopg2.OperationalError as e:
            print(f"Error al conectar a la base de datos (intento {retries + 1}/{max_retries}): {e}")
            time.sleep(delay)
            retries += 1
        except Exception as e:
            print("Error inesperado al conectar a la base de datos:", e)
            raise
    print("No se pudo conectar a la base de datos después de varios intentos.")
    raise psycopg2.OperationalError("No se pudo conectar a la base de datos.")

# Enviar POST a la API de XM
def consultar_api(metric_id, entity, tipo):
    tipo_normalizado = tipo.lower().replace('entities', '').strip()
    url = f"https://servapibi.xm.com.co/{tipo_normalizado}"
    resultados = []

    fecha_inicio = datetime.strptime(START_DATE, "%Y-%m-%d")
    fecha_fin = datetime.strptime(END_DATE, "%Y-%m-%d")

    while fecha_inicio < fecha_fin:
        tramo_fin = min(fecha_inicio + timedelta(days=30), fecha_fin)
        payload = {
            "MetricId": metric_id,
            "StartDate": fecha_inicio.strftime("%Y-%m-%d"),
            "EndDate": tramo_fin.strftime("%Y-%m-%d"),
            "Entity": entity,
            "Filter": []
        }
        print("POST", url)
        print("Payload:", payload)
        response = requests.post(url, json=payload)

        if response.ok:
            data = response.json()
            print("Respuesta:", data)
            resultados.append(data)
        else:
            print(f"Error en {metric_id}: {response.status_code}")
            print("Respuesta:", response.text)
        fecha_inicio = tramo_fin + timedelta(days=1)

    return resultados

# Procesar e insertar datos
def insertar_datos(conn, tabla, datos, metric_id):
    cursor = conn.cursor()
    for row in datos:
        try:
            if tabla == 'demanda_energia':
                fecha = row.get("Fecha")
                for hour in range(1, 25):
                    hour_key = f'Hour{hour:02d}'
                    carga_sin_str = row.get(hour_key)
                    if carga_sin_str is not None and carga_sin_str != '':
                        try:
                            carga_sin = float(carga_sin_str)
                            cursor.execute("""
                                INSERT INTO demanda_energia (carga_sin, fecha_registro, mercado_id)
                                VALUES (%s, %s, %s)
                            """, (carga_sin, fecha, 1))
                        except ValueError:
                            print(f"Error de tipo al insertar demanda (hora {hour_key}): '{carga_sin_str}' no es un número.")
                            conn.rollback()
                        except Exception as e:
                            print(f"Error al insertar demanda (hora {hour_key}): {e}, datos={row}")
                            conn.rollback()
            elif tabla == 'generacion_energia':
                tipo_generacion = row.get("TipoGeneracion")
                energia_str = row.get("Energia")
                capacidad_str = row.get("Capacidad")
                co2_str = row.get("CO2")
                fecha = row.get("Fecha")
                try:
                    energia = float(energia_str) if energia_str not in [None, ''] else None
                    capacidad = float(capacidad_str) if capacidad_str not in [None, ''] else None
                    co2 = float(co2_str) if co2_str not in [None, ''] else None
                    cursor.execute("""
                        INSERT INTO generacion_energia (tipo_generacion, energia_generada, capacidad_instalada, emisiones_co2, infraestructura_id, fecha_registro)
                        VALUES (%s, %s, %s, %s, %s, %s)
                    """, (tipo_generacion, energia, capacidad, co2, 1, fecha))
                except ValueError:
                    print(f"Error de tipo al insertar generación: datos={row}")
                    conn.rollback()
                except Exception as e:
                    print(f"Error al insertar generación: {e}, datos={row}")
                    conn.rollback()
            elif tabla == 'infraestructura':
                capacidad_instalada_str = row.get("Capacidad")
                indice_confiabilidad_str = row.get("Confiabilidad")
                perdidas_energia_str = row.get("Perdidas")
                volumen_embalses_str = row.get("Volumen")
                capacidad_faltante_str = row.get("Faltante")
                try:
                    capacidad_instalada = float(capacidad_instalada_str) if capacidad_instalada_str not in [None, ''] else None
                    indice_confiabilidad = float(indice_confiabilidad_str) if indice_confiabilidad_str not in [None, ''] else None
                    perdidas_energia = float(perdidas_energia_str) if perdidas_energia_str not in [None, ''] else None
                    volumen_embalses = float(volumen_embalses_str) if volumen_embalses_str not in [None, ''] else None
                    capacidad_faltante = float(capacidad_faltante_str) if capacidad_faltante_str not in [None, ''] else None
                    cursor.execute("""
                        INSERT INTO infraestructura (capacidad_instalada, indice_confiabilidad, perdidas_energia, volumen_embalses, capacidad_faltante)
                        VALUES (%s, %s, %s, %s, %s)
                    """, (capacidad_instalada, indice_confiabilidad, perdidas_energia, volumen_embalses, capacidad_faltante))
                except ValueError:
                    print(f"Error de tipo al insertar infraestructura: datos={row}")
                    conn.rollback()
                except Exception as e:
                    print(f"Error al insertar infraestructura: {e}, datos={row}")
                    conn.rollback()
            elif tabla == 'mercado_mayorista':
                precio_bolsa_promedio_str = row.get("Precio")
                volumen_embalses_mercado_str = row.get("Volumen")
                try:
                    precio_bolsa_promedio = float(precio_bolsa_promedio_str) if precio_bolsa_promedio_str not in [None, ''] else None
                    volumen_embalses_mercado = float(volumen_embalses_mercado_str) if volumen_embalses_mercado_str not in [None, ''] else None
                    cursor.execute("""
                        INSERT INTO mercado_mayorista (precio_bolsa_promedio, volumen_embalses)
                        VALUES (%s, %s)
                    """, (precio_bolsa_promedio, volumen_embalses_mercado))
                except ValueError:
                    print(f"Error de tipo al insertar mercado_mayorista: datos={row}")
                    conn.rollback()
                except Exception as e:
                    print(f"Error al insertar mercado_mayorista: {e}, datos={row}")
                    conn.rollback()
            elif tabla == 'sostenibilidad_regulacion':
                emisiones_co2_str = row.get("CO2")
                participacion_renovables_str = row.get("Renovables")
                eficiencia_suministro_str = row.get("Eficiencia")
                fecha_evaluacion = row.get("Fecha")
                try:
                    emisiones_co2 = float(emisiones_co2_str) if emisiones_co2_str not in [None, ''] else None
                    participacion_renovables = float(participacion_renovables_str) if participacion_renovables_str not in [None, ''] else None
                    eficiencia_suministro = float(eficiencia_suministro_str) if eficiencia_suministro_str not in [None, ''] else None
                    cursor.execute("""
                        INSERT INTO sostenibilidad_regulacion (emisiones_co2, participacion_renovables, eficiencia_suministro, generacion_id, demanda_id, fecha_evaluacion)
                        VALUES (%s, %s, %s, %s, %s, %s)
                    """, (emisiones_co2, participacion_renovables, eficiencia_suministro, 1, 1, fecha_evaluacion))
                except ValueError:
                    print(f"Error de tipo al insertar sostenibilidad_regulacion: datos={row}")
                    conn.rollback()
                except Exception as e:
                    print(f"Error al insertar sostenibilidad_regulacion: {e}, datos={row}")
                    conn.rollback()
        except Exception as e:
            print(f"Error general al procesar fila para {tabla}: {e}, datos={row}")
            conn.rollback()
    conn.commit()
    cursor.close()

# Ejecutar el proceso completo
def ejecutar():
    conn = conectar_db()
    try:
        for _, fila in df.iterrows():
            metric = fila['MetricId']
            tipo = fila['Type']
            entity = fila['Entity']
            tabla = TABLA_POR_METRICA.get(metric[:5], None)
            if not tabla:
                continue
            print(f"\nConsultando {metric} → {tabla}")
            resultados = consultar_api(metric, entity, tipo)
            for resultado in resultados:
                if resultado and 'HourlyEntities' in resultado:
                    for entidad in resultado['HourlyEntities']:
                        datos = entidad.get("Values", {})
                        datos["Fecha"] = resultado['Date']  # Asegúrate de agregar la fecha
                        insertar_datos(conn, tabla, [datos], metric)  # Asegúrate de pasar una lista
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    ejecutar()