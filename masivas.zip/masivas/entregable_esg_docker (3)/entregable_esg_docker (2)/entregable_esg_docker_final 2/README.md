## 🛠️ Instrucciones de Uso

1. Clona este repositorio o descarga el archivo ZIP.
2. Asegúrate de tener Docker y Docker Compose instalados.
3. Desde la carpeta raíz del proyecto, corre:

```bash
docker-compose up -d
```

4. Verifica que los contenedores estén funcionando:

```bash
docker ps
```

5. Accede a PostgreSQL:

```bash
psql -h localhost -U postgres -d esg_bd
```

Las credenciales por defecto son:

- Usuario: `postgres`
- Contraseña: `admin`


Despues abrimos una nueva terminal en donde tengamos la raiz del repositorio

Ejecutamos lo siguiente

```bash
pip install requests pandas psycopg2-binary
```

y despues...

```bash
python cargar_datos_xm.py
```

