CREATE TABLE infraestructura (
    id SERIAL PRIMARY KEY,
    capacidad_instalada DECIMAL(10,2),
    indice_confiabilidad DECIMAL(5,2),
    perdidas_energia DECIMAL(5,2),
    volumen_embalses DECIMAL(5,2),
    capacidad_faltante DECIMAL(5,2)
);

CREATE TABLE mercado_mayorista (
    id SERIAL PRIMARY KEY,
    precio_bolsa_promedio DECIMAL(10,2),
    volumen_embalses DECIMAL(5,2)
);

CREATE TABLE demanda_energia (
    id SERIAL PRIMARY KEY,
    carga_sin DECIMAL(10,2),
    energia_faltante DECIMAL(10,2),
    factor_carga DECIMAL(5,2),
    fecha_registro DATE,
    mercado_id INT,
    CONSTRAINT fk_demanda_mercado FOREIGN KEY (mercado_id) REFERENCES mercado_mayorista(id)
);

CREATE TABLE generacion_energia (
    id SERIAL PRIMARY KEY,
    tipo_generacion VARCHAR(50) NOT NULL,
    energia_generada DECIMAL(10,2),
    capacidad_instalada DECIMAL(10,2),
    emisiones_co2 DECIMAL(10,2),
    infraestructura_id INT,
    fecha_registro DATE,
    CONSTRAINT fk_generacion_infraestructura FOREIGN KEY (infraestructura_id) REFERENCES infraestructura(id)
);

CREATE TABLE sostenibilidad_regulacion (
    id SERIAL PRIMARY KEY,
    emisiones_co2 DECIMAL(10,2),
    participacion_renovables DECIMAL(5,2),
    eficiencia_suministro DECIMAL(5,2),
    generacion_id INT,
    demanda_id INT,
    fecha_evaluacion DATE,
    CONSTRAINT fk_sostenibilidad_generacion FOREIGN KEY (generacion_id) REFERENCES generacion_energia(id),
    CONSTRAINT fk_sostenibilidad_demanda FOREIGN KEY (demanda_id) REFERENCES demanda_energia(id)
);