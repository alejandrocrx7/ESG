CREATE TABLE IF NOT EXISTS infraestructura (
    id SERIAL PRIMARY KEY,
    capacidad_instalada DECIMAL(10,2),
    indice_confiabilidad DECIMAL(5,2),
    perdidas_energia DECIMAL(5,2),
    volumen_embalses DECIMAL(5,2),
    capacidad_faltante DECIMAL(5,2)
);

CREATE TABLE IF NOT EXISTS mercado_mayorista (
    id SERIAL PRIMARY KEY,
    precio_bolsa_promedio DECIMAL(10,2),
    volumen_embalses DECIMAL(5,2)
);

CREATE TABLE IF NOT EXISTS demanda_energia (
    id SERIAL PRIMARY KEY,
    carga_sin DECIMAL(10,2),
    energia_faltante DECIMAL(10,2),
    factor_carga DECIMAL(5,2),
    fecha_registro DATE,
    mercado_id INT
);

CREATE TABLE IF NOT EXISTS generacion_energia (
    id SERIAL PRIMARY KEY,
    tipo_generacion VARCHAR(50) NOT NULL,
    energia_generada DECIMAL(10,2),
    capacidad_instalada DECIMAL(10,2),
    emisiones_co2 DECIMAL(10,2),
    infraestructura_id INT,
    fecha_registro DATE
);

CREATE TABLE IF NOT EXISTS sostenibilidad_regulacion (
    id SERIAL PRIMARY KEY,
    emisiones_co2 DECIMAL(10,2),
    participacion_renovables DECIMAL(5,2),
    eficiencia_suministro DECIMAL(5,2),
    generacion_id INT,
    demanda_id INT,
    fecha_evaluacion DATE
);